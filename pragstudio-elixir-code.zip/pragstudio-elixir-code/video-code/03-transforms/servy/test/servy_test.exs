defmodule ServyTest do
  use ExUnit.Case
  doctest Servy

  test "the truth" do
    assert 1 + 1 == 2
  end
end
