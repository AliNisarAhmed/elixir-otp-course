# Frequently Asked Questions

- **Have you really seen Bigfoot?**

	Yes! In this [totally believable video](https://www.youtube.com/watch?v=v77ijOO8oAk)!

- **No, I mean seen Bigfoot *on the refuge*?**

	Oh! Not yet, but we're <em>still looking</em>...

- **Can you just show me some code?**

	Sure! Here's some Elixir:

	```elixir
	["Bigfoot", "Yeti", "Sasquatch"] |> Enum.random()
	```
